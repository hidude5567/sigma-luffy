function doodoo() {
  var ss = prompt("password");
  if (ss == "songsss") {
    window.location.href = "r.html";
  }
}
  